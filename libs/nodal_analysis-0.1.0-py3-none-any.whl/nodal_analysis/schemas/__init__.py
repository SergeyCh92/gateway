from .request import NodeAnalysisRequest, OilData
