from .ipr import IprRequest
